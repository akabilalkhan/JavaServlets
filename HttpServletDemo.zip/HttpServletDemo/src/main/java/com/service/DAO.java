package com.service;

import java.util.ArrayList;
import java.util.List;

public class DAO {
	List<User> users = new ArrayList<>();
	static DAO dao = null;
	private DAO() {
		
	}
	public static DAO getInstance() {
		if(dao==null) {
			dao = new DAO();
		}
		return dao;
	}

}
