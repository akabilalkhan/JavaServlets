package com.service;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.http.HttpRequest;

import javax.naming.ldap.Rdn;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ServiceServlet extends HttpServlet{

	@Override
	public void init() throws ServletException {
		// TODO Auto-generated method stub
		super.init();
	}
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		String helper = req.getParameter("loginhelper");
		if(helper.equals("login")) {
			loginHelper(req, resp);
			return;
		}
		String name = req.getParameter("name");
		int age = Integer.parseInt(req.getParameter("age"));
		String email = req.getParameter("email");
		String password = req.getParameter("password");
		User newUser = new User(name, age, email, password);
		PrintWriter out = resp.getWriter();
		DAO.getInstance().users.add(newUser);

		RequestDispatcher rd = req.getRequestDispatcher("login.html");
		out.println("<h2>You have successfully registered! Please Login</h2>");
		resp.setContentType("text/html");
		rd.include(req, resp);

	}

	void loginHelper(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
		PrintWriter out = resp.getWriter();

		String email = req.getParameter("email");
		String password = req.getParameter("password");
		boolean found = false;
		for(User users : DAO.getInstance().users) {
			if(users.getEmail().equals(email) && users.getPassword().equals(password)) {
				found = true;
				break;
			}
		}
		if(found) {
			resp.setContentType("text/html");
			out.print("<h2>Successfully Logged in!</h2>");
			out.print("<a href=index.html> <button>Logout</button></a?>");
			
		}else {
			RequestDispatcher rd = req.getRequestDispatcher("login.html");
			out.println("<h2>Either email or password is wrong. Try again!</h2>");
			resp.setContentType("text/html");
			rd.include(req, resp);
		}

	}
	@Override
	public void destroy() {
		// TODO Auto-generated method stub
		DAO.getInstance().users.clear();
	}

}



class User{
	String name;
	int age;
	String email;
	String password;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public User(String name, int age, String email, String password) {
		super();
		this.name = name;
		this.age = age;
		this.email = email;
		this.password = password;
	}


}
